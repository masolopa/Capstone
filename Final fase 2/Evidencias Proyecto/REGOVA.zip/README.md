## Cómo iniciar REGOVA

Todos los accesos están en `ejecutables/`. Lee [el flujo de ejecución](ejecutables/README.md) antes de preparar otro equipo. Para uso diario: `ejecutables/INICIAR_REGOVA.bat`.

# React + TypeScript + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Oxc](https://oxc.rs)
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/)

## React Compiler

The React Compiler is not enabled on this template because of its impact on dev & build performances. To add it, see [this documentation](https://react.dev/learn/react-compiler/installation).

## Expanding the ESLint configuration

If you are developing a production application, we recommend updating the configuration to enable type-aware lint rules:

```js
export default defineConfig([
  globalIgnores(['dist']),
  {
    files: ['**/*.{ts,tsx}'],
    extends: [
      // Other configs...

      // Remove tseslint.configs.recommended and replace with this
      tseslint.configs.recommendedTypeChecked,
      // Alternatively, use this for stricter rules
      tseslint.configs.strictTypeChecked,
      // Optionally, add this for stylistic rules
      tseslint.configs.stylisticTypeChecked,

      // Other configs...
    ],
    languageOptions: {
      parserOptions: {
        project: ['./tsconfig.node.json', './tsconfig.app.json'],
        tsconfigRootDir: import.meta.dirname,
      },
      // other options...
    },
  },
])

```

You can also install [eslint-plugin-react-x](https://npmx.dev/package/eslint-plugin-react-x) and [eslint-plugin-react-dom](https://npmx.dev/package/eslint-plugin-react-dom) for React-specific lint rules:

```js
// eslint.config.js
import reactX from 'eslint-plugin-react-x'
import reactDom from 'eslint-plugin-react-dom'

export default defineConfig([
  globalIgnores(['dist']),
  {
    files: ['**/*.{ts,tsx}'],
    extends: [
      // Other configs...
      // Enable lint rules for React
      reactX.configs['recommended-typescript'],
      // Enable lint rules for React DOM
      reactDom.configs.recommended,
    ],
    languageOptions: {
      parserOptions: {
        project: ['./tsconfig.node.json', './tsconfig.app.json'],
        tsconfigRootDir: import.meta.dirname,
      },
      // other options...
    },
  },
])

```


## Alcance actual: MVP de un solo local

Este prototipo usa **un único local ficticio (Maipú)** y tres jerarquías operativas: **Administrador, Supervisor y Reponedor**. La cuenta `ADM-001` sigue siendo la cuenta administrativa protegida de arranque; no es una cuarta jerarquía operativa. Los roles globales/regionales previos se conservan internamente por compatibilidad, pero no se ofrecen para crear usuarios nuevos en el MVP.

- Administración de cuentas: alta, edición de rol, suspensión, reactivación y baja con confirmación y auditoría en el servidor del local.
- Las cuentas nuevas quedan asociadas al local piloto; las cuentas heredadas de otras sucursales no aparecen en el listado del MVP.
- Las cuentas se gestionan en PostgreSQL con hash Argon2 y permisos comprobados en FastAPI. El despliegue sigue siendo local para la tesis.
- API integrada con FastAPI y PostgreSQL. Preparación e inicio: ver BACKEND_REGOVA.md.
- Para una futura expansión, usar `local_id` como relación estable en usuarios, góndolas y análisis; la baja de usuario no debe eliminar su historial de operaciones.

Inicio de sesión: `ADM-001` con la contraseña definida en herramientas/PREPARAR_POSTGRESQL.bat. Las cuentas antiguas de localStorage no se usan para autenticar.
