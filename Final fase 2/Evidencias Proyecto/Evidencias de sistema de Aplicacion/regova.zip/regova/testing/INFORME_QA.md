# Informe QA de componentes — REGOVA

Ejecución: 2026-11-15T20:02:50.229000-03:00. Entorno: Windows, Node v24.20.0, Vitest ^5.1.0, jsdom y React Testing Library. Interfaz REGOVA v1.0; package.json 0.0.0. La huella de los archivos evaluados se incluye en manifest.json.

## Resultado

50 ejecuciones: 50 aprobadas, 0 fallidas, 0 omitidas. Son 43 identificadores de caso; algunos se ejecutan con varias combinaciones de roles o estados. No se realizaron comparaciones visuales ni recorridos en navegador real.

## Alcance y metodología

Componentes Login (incluye recuperación), Users y Alerts. Se utiliza renderizado DOM en jsdom, interacción mediante user-event y respuestas HTTP simuladas en fetch. Los servicios reales del frontend procesan estas respuestas: no se sustituyen por funciones que siempre aprueban. Cada prueba verifica una salida observable, una solicitud o una acción bloqueada.

Los códigos CU-AUT, CU-REC, CU-ALT y CU-USU son agrupaciones de este plan de QA, no identificadores oficiales de la tesis. Deben homologarse con su matriz de requisitos antes de la entrega académica.

Precondiciones por grupo:
- CU-AUT: Componente Login montado sin sesión; respuestas HTTP simuladas; datos ficticios.
- CU-REC: Login en recuperación o con token ficticio en el fragmento de la URL; API simulada.
- CU-ALT: Tres alertas ficticias con estados y responsables controlados; rol indicado por el caso.
- CU-PER: Usuarios ficticios de roles y locales controlados; funciones reales de permisos del frontend.
- CU-USU: Administrador ficticio y listado controlado con una cuenta protegida y un reponedor.

Las entradas exactas, acciones y aserciones están en src/test/components.test.tsx. Se usan correos de prueba y contraseñas ficticias; no se consulta la BD ni se envían correos.

## Matriz de ejecución

| Caso | Grupo | Resultado esperado / comportamiento | Resultado observado | Estado | Duración ms |
|---|---|---|---|---|---:|
| QA-001 | CU-AUT | Inicio de sesión | autentica por ID y entrega la sesión recibida | Las aserciones de comportamiento se cumplieron. | passed | 381.6 |
| QA-002 | CU-AUT | Inicio de sesión | admite correo institucional como identificador | Las aserciones de comportamiento se cumplieron. | passed | 547.1 |
| QA-003 | CU-AUT | Inicio de sesión | muestra rechazo sin iniciar sesión | Las aserciones de comportamiento se cumplieron. | passed | 244.0 |
| QA-004 | CU-AUT | Inicio de sesión | no envía el formulario con contraseña vacía | Las aserciones de comportamiento se cumplieron. | passed | 61.5 |
| QA-005 | CU-AUT | Inicio de sesión | permite mostrar y ocultar la contraseña | Las aserciones de comportamiento se cumplieron. | passed | 119.3 |
| QA-006 | CU-REC | Recuperación | solicita recuperación por correo y muestra confirmación | Las aserciones de comportamiento se cumplieron. | passed | 385.9 |
| QA-007 | CU-REC | Recuperación | presenta un error de configuración sin éxito falso | Las aserciones de comportamiento se cumplieron. | passed | 339.6 |
| QA-008 | CU-REC | Recuperación | bloquea solicitudes duplicadas mientras espera | Las aserciones de comportamiento se cumplieron. | passed | 322.2 |
| QA-009 | CU-REC | Recuperación | rechaza contraseñas de confirmación distintas | Las aserciones de comportamiento se cumplieron. | passed | 459.7 |
| QA-010 | CU-REC | Recuperación | cambia contraseña y elimina el token de la dirección | Las aserciones de comportamiento se cumplieron. | passed | 507.9 |
| QA-011 | CU-REC | Recuperación | informa enlace vencido sin volver al login | Las aserciones de comportamiento se cumplieron. | passed | 470.5 |
| QA-012 | CU-ALT | Alertas | filtra por estado y referencia | Las aserciones de comportamiento se cumplieron. | passed | 306.2 |
| QA-013 | CU-ALT | Alertas | admin_principal consulta sin botones de atención | Las aserciones de comportamiento se cumplieron. | passed | 36.5 |
| QA-013 | CU-ALT | Alertas | supervisor consulta sin botones de atención | Las aserciones de comportamiento se cumplieron. | passed | 66.9 |
| QA-014 | CU-ALT | Alertas | reponedor toma una alerta pendiente | Las aserciones de comportamiento se cumplieron. | passed | 82.8 |
| QA-015 | CU-ALT | Alertas | bloquea tomar una alerta asignada a otra persona | Las aserciones de comportamiento se cumplieron. | passed | 22.3 |
| QA-016 | CU-ALT | Alertas | reponedor marca como atendida su reposición | Las aserciones de comportamiento se cumplieron. | passed | 75.3 |
| QA-017 | CU-ALT | Alertas | error de carga ofrece reintentar | Las aserciones de comportamiento se cumplieron. | passed | 23.8 |
| QA-018 | CU-USU | Gestión de usuarios | crea cuenta con el correo indicado por el trabajador | Las aserciones de comportamiento se cumplieron. | passed | 922.4 |
| QA-019 | CU-USU | Gestión de usuarios | no crea cuentas sin correo | Las aserciones de comportamiento se cumplieron. | passed | 596.0 |
| QA-020 | CU-USU | Gestión de usuarios | conserva protegida la cuenta administrativa principal | Las aserciones de comportamiento se cumplieron. | passed | 44.8 |
| QA-021 | CU-USU | Gestión de usuarios | permite editar correo de una cuenta existente | Las aserciones de comportamiento se cumplieron. | passed | 530.5 |
| QA-022 | CU-USU | Gestión de usuarios | suspensión solicita estado inactivo sin eliminar cuenta | Las aserciones de comportamiento se cumplieron. | passed | 100.3 |
| QA-023 | CU-USU | Gestión de usuarios | cancelar eliminación no envía DELETE | Las aserciones de comportamiento se cumplieron. | passed | 139.8 |
| QA-024 | CU-USU | Gestión de usuarios | muestra errores de carga de cuentas | Las aserciones de comportamiento se cumplieron. | passed | 28.5 |
| QA-025 | CU-USU | Casos ampliados | confirmar baja envía DELETE para la cuenta elegida | Las aserciones de comportamiento se cumplieron. | passed | 139.9 |
| QA-026 | CU-USU | Casos ampliados | reactivar conserva rol y solicita estado activo | Las aserciones de comportamiento se cumplieron. | passed | 96.5 |
| QA-027 | CU-USU | Casos ampliados | cambiar rol envía supervisor manteniendo correo | Las aserciones de comportamiento se cumplieron. | passed | 195.6 |
| QA-028 | CU-USU | Casos ampliados | guardar correo propio exige contraseña actual y envía PUT | Las aserciones de comportamiento se cumplieron. | passed | 762.5 |
| QA-029 | CU-USU | Casos ampliados | fallo al guardar usuario conserva edición y muestra error | Las aserciones de comportamiento se cumplieron. | passed | 140.8 |
| QA-030 | CU-USU | Casos ampliados | supervisor no ve administración de cuentas | Las aserciones de comportamiento se cumplieron. | passed | 4.2 |
| QA-030 | CU-USU | Casos ampliados | reponedor no ve administración de cuentas | Las aserciones de comportamiento se cumplieron. | passed | 4.8 |
| QA-031 | CU-ALT | Casos ampliados | muestra estado vacío sin alertas | Las aserciones de comportamiento se cumplieron. | passed | 20.0 |
| QA-032 | CU-ALT | Casos ampliados | búsqueda sin coincidencias explica el resultado | Las aserciones de comportamiento se cumplieron. | passed | 182.0 |
| QA-033 | CU-ALT | Casos ampliados | fallo de actualización conserva estado pendiente | Las aserciones de comportamiento se cumplieron. | passed | 107.9 |
| QA-033 | CU-ALT | Casos ampliados | fallo de actualización conserva estado en_atencion | Las aserciones de comportamiento se cumplieron. | passed | 97.4 |
| QA-034 | CU-AUT | Validación y conectividad ampliadas | fallo de red no abre sesión y permite reintentar | Las aserciones de comportamiento se cumplieron. | passed | 328.3 |
| QA-035 | CU-AUT | Validación y conectividad ampliadas | correo inválido bloquea recuperación antes de enviar | Las aserciones de comportamiento se cumplieron. | passed | 385.5 |
| QA-036 | CU-AUT | Validación y conectividad ampliadas | regresar desde recuperación vuelve al formulario de acceso | Las aserciones de comportamiento se cumplieron. | passed | 106.9 |
| QA-037 | CU-AUT | Validación y conectividad ampliadas | declara un mínimo de diez caracteres para la nueva contraseña | Las aserciones de comportamiento se cumplieron. | passed | 13.0 |
| QA-038 | CU-PER | Reglas de permisos del frontend | admin_principal no puede modificar su propia cuenta por gestión | Las aserciones de comportamiento se cumplieron. | passed | 0.4 |
| QA-038 | CU-PER | Reglas de permisos del frontend | admin_local no puede modificar su propia cuenta por gestión | Las aserciones de comportamiento se cumplieron. | passed | 0.3 |
| QA-038 | CU-PER | Reglas de permisos del frontend | supervisor no puede modificar su propia cuenta por gestión | Las aserciones de comportamiento se cumplieron. | passed | 0.2 |
| QA-038 | CU-PER | Reglas de permisos del frontend | reponedor no puede modificar su propia cuenta por gestión | Las aserciones de comportamiento se cumplieron. | passed | 0.2 |
| QA-039 | CU-PER | Reglas de permisos del frontend | supervisor no puede crear cuentas ni asignar roles | Las aserciones de comportamiento se cumplieron. | passed | 0.3 |
| QA-039 | CU-PER | Reglas de permisos del frontend | reponedor no puede crear cuentas ni asignar roles | Las aserciones de comportamiento se cumplieron. | passed | 0.2 |
| QA-040 | CU-PER | Reglas de permisos del frontend | administrador local no modifica principal ni pares | Las aserciones de comportamiento se cumplieron. | passed | 0.3 |
| QA-041 | CU-PER | Reglas de permisos del frontend | bloquea usuarios de otro local y territorio desconocido | Las aserciones de comportamiento se cumplieron. | passed | 1.0 |
| QA-042 | CU-PER | Reglas de permisos del frontend | administrador local puede gestionar subordinados sin promover a administrador | Las aserciones de comportamiento se cumplieron. | passed | 0.3 |
| QA-043 | CU-PER | Reglas de permisos del frontend | atender alertas corresponde exclusivamente al reponedor | Las aserciones de comportamiento se cumplieron. | passed | 0.3 |

## Cobertura del alcance seleccionado

| Medida | Porcentaje | Cubierto / total |
|---|---:|---:|
| Líneas | 84.38 % | 200 / 237 |
| Sentencias | 82.22 % | 273 / 332 |
| Funciones | 82.85 % | 87 / 105 |
| Ramas | 79.12 % | 216 / 273 |

La cobertura incluye tres componentes y cuatro servicios relacionados, definidos en vitest.config.ts. No es cobertura del sistema completo. El 100 % de aprobación de estos casos no implica ausencia de defectos.

## Hallazgos y seguimiento

- La ejecución final no detectó incumplimientos en los 50 escenarios evaluados. No se modificó la lógica funcional de los componentes para obtener aprobación.
- Durante la preparación se corrigieron dos problemas del arnés: una búsqueda de etiqueta demasiado estricta y la reutilización de una Response ya consumida en el mock. También se corrigieron opciones de tipado de las consultas de prueba. No se clasifican como defectos de REGOVA.
- npm audit informó 9 vulnerabilidades moderadas en el árbol de herramientas ESLint/TypeScript; ninguna alta ni crítica. Se adjunta el resultado audit-dependencies.json. Este comando no sustituye una auditoría de seguridad. No se aplicaron actualizaciones incompatibles automáticamente.
- Ampliación: confirmación de baja, reactivación, edición de roles, correo propio, errores de guardado, estados vacíos, fallos de red y permisos negativos. La longitud mínima se verifica como atributo HTML en jsdom y como rechazo HTTP 422 real en FastAPI; jsdom no reproduce completamente minlength.
- Pendiente: pantallas de configuración, panorama general, análisis y resultados en la suite frontend; más variantes de errores y roles heredados.

## Fuera de alcance

Fuera del frontend aislado: autorización y persistencia del servidor. Estas se verificaron adicionalmente mediante pytest y PostgreSQL real, según el apartado siguiente. Siguen fuera de esta ejecución: entrega SMTP real, compatibilidad entre navegadores, pruebas visuales, rendimiento y precisión del detector. Mostrar un error simulado de enlace vencido verifica la UI, no el vencimiento real. Ocultar botones verifica la interfaz, no la seguridad del backend.

## Reproducción

Desde la carpeta del proyecto, ejecutar npm ci, luego npm run test:qa. El proceso devuelve error si falla una prueba. Para regenerar este informe después de la ejecución: backend/.venv/Scripts/python.exe scripts/qa_report.py. Alternativa: ejecutar EJECUTAR_QA.bat. Requiere el entorno Python existente solo para el informe narrativo.

Archivos: reports/qa/results.json (resultados), reports/qa/junit.xml (intercambio), reports/qa/coverage/index.html (cobertura), .vitest/index.html (visor Vitest; servir con npx vite preview --outDir .vitest), reports/qa/INFORME_QA.html (informe autónomo legible sin servidor).

## Criterio de aceptación

Todos los casos seleccionados aprobados, sin pruebas omitidas, con evidencia y cobertura publicadas. Esta ejecución satisface ese criterio para el alcance indicado. No constituye una certificación de seguridad ni una aprobación de producción.


## Ejecución adicional de backend con PostgreSQL real

71 pruebas; 0 fallidas; 0 omitidas. Evidencia: backend-junit.xml. PostgreSQL 18 temporal en loopback y puerto independiente, base REGOVA_QA_TEST, esquema creado con migraciones 000–003 y almacenamiento temporal. No se utilizó REGOVA_BD. El rol propietario de la instancia de prueba no reproduce los permisos SQL limitados del usuario de producción. SMTP se sustituyó por una captura local del token, sin enviar mensajes.

Casos nuevos: persistencia Argon2, rechazo de contraseña anterior, enlace de un solo uso, token expirado, contraseña demasiado corta, revocación de sesiones, recuperación bloqueada de cuenta suspendida, dos cambios concurrentes con el mismo token y dos reponedores compitiendo por una alerta. Incluye la suite previa de API y servicios.

| Prueba backend | Resultado | Duración s |
|---|---|---:|
| test_auth_cookie_logout_and_no_plaintext | aprobada | 0.884 |
| test_reponedor_cannot_analyze_change_settings_or_users | aprobada | 1.084 |
| test_supervisor_analysis_persists_raw_original_and_real_author | aprobada | 2.487 |
| test_threshold_version_and_original_result_immutable | aprobada | 1.394 |
| test_expired_suspended_session_and_protected_admin | aprobada | 1.544 |
| test_invalid_image_geometry_origin_and_pasillo | aprobada | 1.408 |
| test_local_isolation | aprobada | 1.719 |
| test_failure_keeps_original_and_failed_state | aprobada | 0.866 |
| test_alert_attendance_and_review_do_not_change_prediction | aprobada | 2.674 |
| test_storage_rejects_traversal_and_no_secret_in_api_docs | aprobada | 0.559 |
| test_bootstrap_model_version_and_reexecution_preserve_account | aprobada | 0.909 |
| test_pasillo_required_normalized_and_editable_without_catalog | aprobada | 2.214 |
| test_historical_dashboard_readonly_pdf_and_local_isolation | aprobada | 2.789 |
| test_qa_recovery_single_use_revokes_sessions_persists_hash | aprobada | 2.036 |
| test_qa_recovery_expired_token_and_short_password_rejected | aprobada | 1.390 |
| test_qa_recovery_concurrent_token_only_one_change | aprobada | 0.978 |
| test_qa_two_workers_cannot_claim_same_alert | aprobada | 1.923 |
| test_qa_suspended_account_cannot_use_existing_recovery | aprobada | 1.133 |
| test_qa_worker_cannot_edit_users_directly | aprobada | 1.127 |
| test_todo_ocupado | aprobada | 0.000 |
| test_todo_vacio | aprobada | 0.000 |
| test_50_por_ciento | aprobada | 0.000 |
| test_30_exacto_alerta | aprobada | 0.000 |
| test_29_alerta | aprobada | 0.001 |
| test_excluidas_no_suman_al_denominador | aprobada | 0.001 |
| test_disponibilidad_mas_vacio_es_100 | aprobada | 0.001 |
| test_division_por_cero_da_no_evaluable | aprobada | 0.001 |
| test_valores_negativos | aprobada | 0.001 |
| test_umbral_invalido | aprobada | 0.000 |
| test_desconocido_no_cuenta_ni_como_vacio_ni_como_ocupado | aprobada | 0.001 |
| test_estructural_no_entra_en_denominador | aprobada | 0.000 |
| test_suma_supera_total | aprobada | 0.000 |
| test_suma_igual_total_ok | aprobada | 0.000 |
| test_negativo_desconocido | aprobada | 0.000 |
| test_redondeo_suma_100[1-2] | aprobada | 0.001 |
| test_redondeo_suma_100[7-3] | aprobada | 0.001 |
| test_redondeo_suma_100[333-667] | aprobada | 0.001 |
| test_redondeo_suma_100[1-999999] | aprobada | 0.001 |
| test_mitad_llena_mitad_vacia | aprobada | 0.015 |
| test_exclusion_no_cuenta | aprobada | 0.006 |
| test_imagen_invalida | aprobada | 0.001 |
| test_preparation_preserves_broken_environment_instead_of_deleting | aprobada | 0.009 |
| test_preparation_reuses_valid_environment_without_installing | aprobada | 0.002 |
| test_start_reuses_current_server_without_starting_another | aprobada | 0.001 |
| test_start_detects_old_server_without_killing_it | aprobada | 0.001 |
| test_email_validation_and_password_spaces | aprobada | 0.001 |
| test_smtp_tls_message_contains_id_and_fragment_link | aprobada | 0.089 |
| test_unknown_email_generic_response_and_no_send | aprobada | 0.002 |
| test_reset_invalid_or_expired_token_never_updates_password | aprobada | 0.134 |
| test_reset_consumes_token_revokes_sessions_and_audits | aprobada | 0.068 |
| test_cuenta_productos_y_filas_automaticas | aprobada | 0.014 |
| test_frentes_ocupados_y_libres_por_fila | aprobada | 0.001 |
| test_fila_con_pocos_productos_se_marca_reponer | aprobada | 0.001 |
| test_productos_apilados_cuentan_como_un_frente | aprobada | 0.001 |
| test_filas_indicadas_por_el_usuario_muestran_fila_vacia | aprobada | 0.002 |
| test_sin_productos_no_inventa_filas | aprobada | 0.000 |
| test_training_status_sin_checkpoint_no_declara_modelo | aprobada | 0.003 |
| test_training_status_dataset_refleja_stats | aprobada | 0.002 |
| test_precedencia_excluido_sobre_estructural_y_evidencia | aprobada | 0.001 |
| test_fuera_de_roi_no_cuenta | aprobada | 0.001 |
| test_sin_evidencia_es_desconocido | aprobada | 0.000 |
| test_poligono_fuera_de_rango | aprobada | 0.000 |
| test_poligono_muy_corto | aprobada | 0.000 |
| test_imagen_borrosa_se_advierte | aprobada | 0.002 |
| test_imagen_oscura_se_advierte | aprobada | 0.003 |
| test_imagen_sobreexpuesta_se_advierte | aprobada | 0.004 |
| test_imagen_nitida_sin_advertencias_de_exposicion | aprobada | 0.005 |
| test_redimensiona_imagen_grande | aprobada | 0.018 |
| test_estructural_se_excluye_del_denominador | aprobada | 0.015 |
| test_roi_limita_el_analisis | aprobada | 0.011 |
| test_no_hay_conteo_doble | aprobada | 0.015 |

Reproducción de integración: ejecutar backend/.venv/Scripts/python.exe scripts/run_backend_qa.py. El asistente requiere PostgreSQL instalado y prepara una instancia temporal; su salida describe la evidencia generada. Las pruebas existentes usan TRUNCATE solo en la base temporal terminada en _TEST.
