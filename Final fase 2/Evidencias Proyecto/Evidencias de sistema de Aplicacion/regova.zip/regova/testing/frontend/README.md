# Testing del frontend

50 ejecuciones aprobadas, sin fallos ni omisiones. 43 identificadores de caso con variantes parametrizadas. Archivos evaluados: Login (incluye recuperación), Users y Alerts, más servicios relacionados.

## Herramientas y fundamento

Vitest ejecuta los casos y mide cobertura mediante V8; React Testing Library renderiza los componentes; user-event simula interacción; jsdom proporciona DOM sin navegador real; jest-dom permite aserciones legibles. Se simula fetch, manteniendo los servicios HTTP reales del frontend. Se evalúa comportamiento observable y no detalles internos de implementación.

## Contenido

- codigo/: copia exacta del código de pruebas, setup y configuración. El origen y sus hashes están en MANIFIESTO_CODIGO.json en la carpeta superior.
- evidencias/results.json y junit.xml: resultados originales.
- evidencias/cobertura/index.html: cobertura del alcance seleccionado (84,38 % de líneas, 200/237).
- evidencias/visor-vitest/: reporte automático; requiere servidor local para cargar sus recursos.

## Ejecución

Desde la raíz de REGOVA: npm ci y npm run test:qa. Alternativa: EJECUTAR_QA.bat. Para el visor: npx vite preview --outDir testing/frontend/evidencias/visor-vitest.

Las copias de codigo/ son evidencia para revisar; ejecutar los originales en src/test, que conservan las rutas de importación al proyecto. No se midieron presentación visual, navegador real ni persistencia. No hay datos personales ni credenciales reales en las pruebas.
