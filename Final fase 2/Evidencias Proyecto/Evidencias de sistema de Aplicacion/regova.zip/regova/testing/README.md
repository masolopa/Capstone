# Testing de REGOVA

Paquete organizado el 15 de noviembre de 2026. Contiene código y evidencia de pruebas ejecutadas, sin credenciales ni copias de la BD operativa.

## Desglose

| Sección | Ejecuciones aprobadas | Fallos | Omitidas |
|---|---:|---:|---:|
| Frontend | 50 | 0 | 0 |
| Backend: API, recuperación y entorno | 28 | 0 | 0 |
| Algoritmo: lógica de visión y cálculos | 43 | 0 | 0 |
| Total | 121 | 0 | 0 |

Las 71 pruebas de pytest se reparten entre backend y algoritmo; no se cuentan dos veces. El XML de ejecución completa se conserva para trazabilidad. Los casos parametrizados cuentan como ejecuciones separadas.

## Estructura

- frontend/codigo y frontend/evidencias
- backend/codigo y backend/evidencias
- algoritmo/codigo y algoritmo/evidencias
- INFORME_QA.html y .md: informe consolidado de la campaña.
- MANIFIESTO_CODIGO.json: relación de copias, ubicaciones originales y hashes SHA-256.
- audit-dependencies.json: revisión auxiliar de dependencias.

## Estrategia y justificación

Se eligieron pruebas automatizadas de comportamiento y lógica para comprobar reglas de negocio de manera repetible. No se hicieron pruebas visuales de capturas ni recorridos con Cypress.

1. Frontend: Vitest + React Testing Library + user-event + jsdom. Adecuados para React/Vite y para comprobar formularios, acciones permitidas, errores y navegación local con respuestas controladas.
2. Backend: pytest + FastAPI TestClient + psycopg + PostgreSQL aislado. Comprueban reglas del servidor y persistencia, evitando confundir la visibilidad de un botón con autorización real.
3. Algoritmo: pytest + NumPy + OpenCV. Comprueban fórmulas, máscaras y procesamiento con datos controlados y reproducibles.

La cobertura V8 del frontend seleccionado alcanzó 84,38 % de líneas; no representa todo REGOVA. No se midió cobertura del backend ni del algoritmo en esta campaña. Aprobación significa que las aserciones de los casos ejecutados se cumplieron; no certifica ausencia de errores.

## Reproducción y mantenimiento

La carpeta codigo/ de cada sección contiene copias de evidencia: las pruebas originales ejecutables permanecen en src/test y backend/tests. Se conservaron para no romper rutas de imports ni comandos existentes. Para modificar o repetir pruebas, trabajar desde la raíz del proyecto; consultar el README de cada sección. Si cambia código o se vuelven a ejecutar pruebas, regenerar informes y volver a sincronizar esta carpeta; no interpretar estas copias como resultados siempre actualizados.

## Pendientes y límites

Faltan pruebas de componentes de configuración, panorama general, análisis y resultados; validación del detector contra fotografías etiquetadas; SMTP real automatizado; navegador real, rendimiento y despliegue. El informe documenta 9 hallazgos moderados de herramientas de desarrollo y una advertencia de deprecación del cliente HTTP de pruebas. No se realizaron cambios de lógica funcional ni de comentarios internos del producto para conseguir aprobación.
