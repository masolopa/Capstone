# Resultados: algoritmo

Estos resultados se desglosan del JUnit de la ejecución real de 71 pruebas; no son una ejecución adicional.

| Prueba | Estado | Duración s |
|---|---|---:|
| test_todo_ocupado | aprobada | 0.000 |
| test_todo_vacio | aprobada | 0.000 |
| test_50_por_ciento | aprobada | 0.000 |
| test_30_exacto_alerta | aprobada | 0.000 |
| test_29_alerta | aprobada | 0.001 |
| test_excluidas_no_suman_al_denominador | aprobada | 0.001 |
| test_disponibilidad_mas_vacio_es_100 | aprobada | 0.001 |
| test_division_por_cero_da_no_evaluable | aprobada | 0.001 |
| test_valores_negativos | aprobada | 0.001 |
| test_umbral_invalido | aprobada | 0.000 |
| test_desconocido_no_cuenta_ni_como_vacio_ni_como_ocupado | aprobada | 0.001 |
| test_estructural_no_entra_en_denominador | aprobada | 0.000 |
| test_suma_supera_total | aprobada | 0.000 |
| test_suma_igual_total_ok | aprobada | 0.000 |
| test_negativo_desconocido | aprobada | 0.000 |
| test_redondeo_suma_100[1-2] | aprobada | 0.001 |
| test_redondeo_suma_100[7-3] | aprobada | 0.001 |
| test_redondeo_suma_100[333-667] | aprobada | 0.001 |
| test_redondeo_suma_100[1-999999] | aprobada | 0.001 |
| test_mitad_llena_mitad_vacia | aprobada | 0.015 |
| test_exclusion_no_cuenta | aprobada | 0.006 |
| test_imagen_invalida | aprobada | 0.001 |
| test_cuenta_productos_y_filas_automaticas | aprobada | 0.014 |
| test_frentes_ocupados_y_libres_por_fila | aprobada | 0.001 |
| test_fila_con_pocos_productos_se_marca_reponer | aprobada | 0.001 |
| test_productos_apilados_cuentan_como_un_frente | aprobada | 0.001 |
| test_filas_indicadas_por_el_usuario_muestran_fila_vacia | aprobada | 0.002 |
| test_sin_productos_no_inventa_filas | aprobada | 0.000 |
| test_training_status_sin_checkpoint_no_declara_modelo | aprobada | 0.003 |
| test_training_status_dataset_refleja_stats | aprobada | 0.002 |
| test_precedencia_excluido_sobre_estructural_y_evidencia | aprobada | 0.001 |
| test_fuera_de_roi_no_cuenta | aprobada | 0.001 |
| test_sin_evidencia_es_desconocido | aprobada | 0.000 |
| test_poligono_fuera_de_rango | aprobada | 0.000 |
| test_poligono_muy_corto | aprobada | 0.000 |
| test_imagen_borrosa_se_advierte | aprobada | 0.002 |
| test_imagen_oscura_se_advierte | aprobada | 0.003 |
| test_imagen_sobreexpuesta_se_advierte | aprobada | 0.004 |
| test_imagen_nitida_sin_advertencias_de_exposicion | aprobada | 0.005 |
| test_redimensiona_imagen_grande | aprobada | 0.018 |
| test_estructural_se_excluye_del_denominador | aprobada | 0.015 |
| test_roi_limita_el_analisis | aprobada | 0.011 |
| test_no_hay_conteo_doble | aprobada | 0.015 |
