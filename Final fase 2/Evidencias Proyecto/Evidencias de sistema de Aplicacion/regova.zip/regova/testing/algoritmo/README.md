# Testing del algoritmo

43 ejecuciones aprobadas, sin fallos ni omisiones. Se separan de backend para distinguir la lógica de análisis de la API y la persistencia.

## Qué se prueba

- Disponibilidad: ocupado/vacío, exclusiones, umbrales y entradas inválidas.
- Línea base: comportamiento del análisis sobre imágenes de prueba.
- Visión: máscaras, precedencia de categorías, región de interés y preprocesamiento.
- Estantes: cálculo y agrupación evaluados por test_shelf_rows.py.
- Estado de entrenamiento: coherencia de metadatos y ausencia de checkpoint.

## Herramientas y justificación

pytest organiza casos y valida invariantes; NumPy genera matrices e imágenes sintéticas reproducibles; OpenCV transforma y analiza esas imágenes. Los casos sintéticos permiten controlar exactamente entradas y salidas esperadas sin depender de fotografías externas variables.

## Evidencia y ejecución

codigo/ contiene copias completas de cinco módulos; evidencias/ contiene su desglose JUnit y tabla de resultados, derivados de la misma ejecución de 71 pruebas del backend.

Desde la raíz de REGOVA:

```powershell
backend/.venv/Scripts/python.exe -m pytest backend/tests/test_availability.py backend/tests/test_baseline.py backend/tests/test_shelf_rows.py backend/tests/test_training.py backend/tests/test_vision_modules.py -q -p no:cacheprovider --basetemp work/pytest-algoritmo-nueva-ejecucion --junitxml reports/qa/algoritmo-junit.xml
```

Usar un directorio temporal nuevo en cada ejecución. Estas pruebas no necesitan la BD operativa.

## Límite fundamental

Que estas pruebas pasen NO demuestra precisión del modelo YOLO. No se midieron mAP, precisión, recall ni error de disponibilidad sobre un conjunto independiente etiquetado. No se reentrenó el modelo. Validar el detector con fotografías representativas y un conjunto reservado de evaluación sigue siendo una tarea separada.
