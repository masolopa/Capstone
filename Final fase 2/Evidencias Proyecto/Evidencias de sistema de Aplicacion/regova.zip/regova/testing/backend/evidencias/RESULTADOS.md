# Resultados: backend

Estos resultados se desglosan del JUnit de la ejecución real de 71 pruebas; no son una ejecución adicional.

| Prueba | Estado | Duración s |
|---|---|---:|
| test_auth_cookie_logout_and_no_plaintext | aprobada | 0.884 |
| test_reponedor_cannot_analyze_change_settings_or_users | aprobada | 1.084 |
| test_supervisor_analysis_persists_raw_original_and_real_author | aprobada | 2.487 |
| test_threshold_version_and_original_result_immutable | aprobada | 1.394 |
| test_expired_suspended_session_and_protected_admin | aprobada | 1.544 |
| test_invalid_image_geometry_origin_and_pasillo | aprobada | 1.408 |
| test_local_isolation | aprobada | 1.719 |
| test_failure_keeps_original_and_failed_state | aprobada | 0.866 |
| test_alert_attendance_and_review_do_not_change_prediction | aprobada | 2.674 |
| test_storage_rejects_traversal_and_no_secret_in_api_docs | aprobada | 0.559 |
| test_bootstrap_model_version_and_reexecution_preserve_account | aprobada | 0.909 |
| test_pasillo_required_normalized_and_editable_without_catalog | aprobada | 2.214 |
| test_historical_dashboard_readonly_pdf_and_local_isolation | aprobada | 2.789 |
| test_qa_recovery_single_use_revokes_sessions_persists_hash | aprobada | 2.036 |
| test_qa_recovery_expired_token_and_short_password_rejected | aprobada | 1.390 |
| test_qa_recovery_concurrent_token_only_one_change | aprobada | 0.978 |
| test_qa_two_workers_cannot_claim_same_alert | aprobada | 1.923 |
| test_qa_suspended_account_cannot_use_existing_recovery | aprobada | 1.133 |
| test_qa_worker_cannot_edit_users_directly | aprobada | 1.127 |
| test_preparation_preserves_broken_environment_instead_of_deleting | aprobada | 0.009 |
| test_preparation_reuses_valid_environment_without_installing | aprobada | 0.002 |
| test_start_reuses_current_server_without_starting_another | aprobada | 0.001 |
| test_start_detects_old_server_without_killing_it | aprobada | 0.001 |
| test_email_validation_and_password_spaces | aprobada | 0.001 |
| test_smtp_tls_message_contains_id_and_fragment_link | aprobada | 0.089 |
| test_unknown_email_generic_response_and_no_send | aprobada | 0.002 |
| test_reset_invalid_or_expired_token_never_updates_password | aprobada | 0.134 |
| test_reset_consumes_token_revokes_sessions_and_audits | aprobada | 0.068 |
