# Testing del backend

28 ejecuciones aprobadas, sin omisiones. Incluye API con PostgreSQL real, recuperación de acceso y preparación del entorno.

## Herramientas y fundamento

pytest permite fixtures, parametrización y aserciones; FastAPI TestClient ejerce las rutas HTTP dentro del proceso; psycopg comprueba persistencia real. Una instancia temporal PostgreSQL 18 aplica las migraciones 000–003 y utiliza almacenamiento temporal. Las carreras se ejercitan con dos hilos y barrera de sincronización.

El envío SMTP se sustituye por captura local del token para evitar correos reales y controlar vencimiento y reutilización. Se comprueban permisos, aislamiento de local, hash de contraseña, sesiones, recuperación y asignación concurrente de alertas. No se accede a REGOVA_BD.

## Contenido y ejecución

codigo/ contiene copias de los tres módulos de pruebas y el asistente de instancia temporal. Los originales están en backend/tests y scripts. evidencias/junit.xml y RESULTADOS.md incluyen solo esta sección; ejecucion-completa-pytest.xml permite rastrear las 71 pruebas originales, incluidas las del algoritmo.

Desde la raíz del proyecto: backend/.venv/Scripts/python.exe scripts/run_backend_qa.py. Este comando ejecuta backend y algoritmo en la instancia temporal y la cierra al finalizar. No usa la BD operativa. Requiere PostgreSQL instalado y dependencias de desarrollo de backend. No ejecutar las copias de codigo/ directamente: sus imports dependen de la estructura original.

Limitaciones: el rol de BD de prueba es propietario, por lo que no verifica privilegios SQL del rol de producción. No se prueba el proveedor SMTP real, despliegue, carga o exposición a Internet. Se registró una advertencia de deprecación Starlette/httpx; no invalidó la ejecución.
