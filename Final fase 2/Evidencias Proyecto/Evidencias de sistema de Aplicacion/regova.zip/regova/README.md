# REGOVA MVP académico

Copia preparada para entregar evidencia del sistema. Incluye frontend React y TypeScript, backend FastAPI, scripts PostgreSQL, pruebas documentadas y el checkpoint YOLO seleccionado.

## Primera instalación

1. Instalar Python 3.13 x64 y PostgreSQL 18 para Windows. El servicio PostgreSQL debe estar iniciado. Se requiere internet para descargar dependencias al preparar los entornos.
2. Ejecutar `ejecutables/PREPARAR_EQUIPO.bat`. Introducir las credenciales del propietario de PostgreSQL de ese equipo y definir una contraseña propia para `ADM-001` cuando se solicite.
3. Esta copia utiliza por defecto la base `REGOVA_EVIDENCIA_BD` y el rol `regova_evidencia_app`, separados de la instalación de trabajo. No se debe elegir una base operacional existente ni reutilizar su configuración privada.
4. Ejecutar `ejecutables/INICIAR_REGOVA.bat`. La interfaz se sirve en `http://127.0.0.1:8011`. Si otra copia está usando ese puerto, detener su consola antes de iniciar esta.
5. Crear las cuentas de Supervisor y Reponedor desde Gestión de usuarios y cargar una fotografía para realizar un análisis.

El asistente crea una base nueva si no existe, aplica las migraciones e inicializa el local ficticio, la cuenta administrativa, los umbrales y el modelo. No se incluye un respaldo con cuentas o contraseñas anteriores. El archivo privado `backend/.env` se genera durante la preparación; `backend/.env.example` contiene solo valores de ejemplo. No ejecutar simultáneamente dos preparaciones.

## Contenido de la evidencia

- `src`, `public` y archivos de configuración: código del frontend.
- `dist`: frontend compilado, necesario para el arranque sin servidor Vite.
- `backend/app`: servicios, acceso a datos, permisos y visión.
- `backend/migrations`: creación y evolución del esquema; conserva las migraciones operacionales 000 a 003.
- `backend/training`: código de preparación, entrenamiento e inferencia.
- `backend/data/training/status.json` y el checkpoint referenciado: modelo seleccionado para inferencia. La preparación lo registra en la base nueva y copia sus pesos a storage.
- `docs`: documentación y modelado existentes.
- `testing`: informes y copias de evidencia de las campañas de pruebas documentadas. Son resultados históricos, no una nueva ejecución sobre esta copia.
- `scripts` y `ejecutables`: herramientas de instalación, arranque y pruebas.

Esta entrega permite instalar y analizar nuevas fotografías. No incluye el historial de capturas del equipo, cuentas previas, correos configurados, respaldos privados, datasets completos ni todos los experimentos de entrenamiento. El material de experimentación permanece en la copia original.

## Desarrollo y pruebas

Para trabajar o ejecutar pruebas del frontend, instalar Node.js compatible con el archivo de dependencias y ejecutar `npm ci` en la raíz. `npm run build` actualiza dist; `npm test` ejecuta las pruebas del frontend. Los entornos Python se recrean con la preparación inicial; para pruebas de desarrollo consultar `backend/requirements-dev.txt` y los README de testing. La carpeta temporal work puede volver a generarse al ejecutar QA.

Los accesos detallados están documentados en `ejecutables/README.md`. Para esta entrega prevalecen las instrucciones anteriores sobre referencias antiguas a una copia completa con historial o a un equipo ya configurado.

## Correo y límites

La recuperación de acceso por correo requiere configurar SMTP y credenciales propias del evaluador en backend/.env. La entrega no incluye credenciales de correo. Un 100 % de ocupación útil estimada no acredita inventario físico en profundidad; los resultados requieren revisión humana.

## Estado de documentación de modelado

Se conserva la documentación recibida como evidencia del desarrollo. La revisión encontró un desfase respecto de la migración 003: el diccionario y ML documentan 14 tablas y 115 campos, mientras que el esquema esperado tras las migraciones actuales tiene 15 tablas y 120 campos. Consultar `REVISION_MODELADO.md`. El script histórico de comprobación SQL también necesita ajustar su conteo antes de usarlo sobre el esquema actualizado. No ejecutar scripts de prueba sobre una base operacional.

## Revisión de esta copia

Se verificó la conservación por SHA-256 del checkpoint seleccionado, la presencia del frontend compilado y de las migraciones, y la sintaxis del código Python. Se revisaron coincidencias con credenciales de la configuración local original, sin encontrarlas en los archivos de texto revisados. No se instaló ni se ejecutó la aplicación contra PostgreSQL durante esta limpieza. Se requiere un ensayo de instalación y análisis en el equipo de evaluación.
