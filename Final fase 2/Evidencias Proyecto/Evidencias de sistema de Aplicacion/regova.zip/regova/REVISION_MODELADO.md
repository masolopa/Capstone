# Revisión de la documentación de modelado de REGOVA

Fecha: 16 de noviembre de 2026.

Se revisó la carpeta `C:/Users/NoahWeon/Downloads/regova/docs/modelado` contra las migraciones y las operaciones actuales del backend. La revisión es estática: no se ejecutaron scripts SQL ni se consultó o modificó la base operacional. No se modificaron los documentos originales.

## Resultado

El modelado existente cubre el núcleo del MVP y ya refleja el análisis por fotografía, pasillo obligatorio, local de sesión y góndolas opcionales por compatibilidad. El desfase principal es la incorporación posterior de recuperación de acceso. También hay instrucciones de instalación antiguas y detalles de operación que faltan en la documentación.

## Hallazgos y correcciones necesarias

### 1 Recuperación de acceso ausente del modelo físico documentado

El esquema de referencia, el diccionario y el ML editable representan 14 tablas y 115 campos. La captura histórica `Esquema_Instalado_PostgreSQL.json` también contiene esas 14 tablas y 115 columnas. Los nombres de columnas documentados coinciden con las tablas comunes de las migraciones actuales.

La migración `backend/migrations/003_recuperacion_acceso.sql` añade `recuperaciones_acceso`: token_hash, usuario_id, email, creada_en y expira_en. Incluye PK, FK a usuarios, restricciones de formato y expiración, e índice por usuario. El asistente `backend/preparar_local.py` aplica 001, 002 y 003; los servicios de recuperación usan la tabla.

Por tanto, una instalación conforme a las migraciones actuales debe representar 15 tablas, 120 columnas y 23 claves foráneas. Estos son valores esperados por los archivos de código; no una nueva certificación de la BD instalada.

Actualizar ML completo y vista de autenticación/operación, diccionario MD/HTML, textos de recuento y paquete SQL de referencia. El MER puede conservar sus 11 entidades de negocio: recuperación de acceso es infraestructura, como sesiones, y no requiere una duodécima entidad de negocio si se explica la diferencia de alcance.

No sustituir la captura histórica por datos calculados ni cambiar su fecha para presentarla como una nueva inspección. Conservarla como evidencia anterior y generar otra captura cuando se contraste la instancia instalada.

### 2 Paquete de instalación documental incompleto

`05_SQL_referencia/Regova_PostgreSQL.sql` contiene el esquema inicial y sesiones, pero omite recuperación de acceso. Las copias 01 de sesiones y 02 de ubicación coinciden exactamente con sus migraciones del backend. Falta la copia correspondiente a 003.

`API_REGOVA.md` describe al final una instalación nueva con 001 y 002, mientras que el asistente actual aplica también 003. Su árbol de migraciones y contrato HTTP tampoco incluyen recuperación, restablecimiento de contraseña y actualización del correo del perfil.

Documentar `POST /api/auth/recovery`, `POST /api/auth/reset-password` y `PUT /api/auth/email`, sus condiciones y la configuración de correo. Distinguir instalación nueva de actualización de una base existente. No ejecutar creación completa sobre la base operacional.

### 3 Script de pruebas estructurales incompatible con la tabla nueva

`05_SQL_referencia/Probar_REGOVA.sql`, líneas 43–46, exige exactamente 13 tablas excluyendo sesiones. Una instalación actual tiene 14 al excluir sesiones porque incorpora recuperaciones_acceso. Por ello, el script rechazará una instalación actual correcta en esa comprobación.

Actualizar la validación al conjunto esperado de tablas y añadir comprobaciones de la recuperación de acceso. El fallo se deduce del código; el script no se ejecutó durante esta revisión.

El script crea registros ficticios para verificar integridad y termina con ROLLBACK. Es evidencia de pruebas, no un poblado persistente para una demostración. Los hashes ficticios de sus cuentas tampoco sirven para iniciar sesión. Esta distinción debe quedar explícita al presentar el entregable de datos de prueba solicitado por el docente.

### 4 Motivo de No procede sin explicación de su persistencia real

El campo `alertas.motivo` describe la condición que originó la alerta. El motivo de su descarte se guarda en `eventos_auditoria.detalle`, con acción `alerta.descartada`, entidad `alertas` e identificador de la alerta. `Repositories.alerts` recupera el último evento correspondiente y expone el dato como `motivo_cierre`.

El cierre conserva además `alertas.estado='descartada'`, `cerrada_por` y `cerrada_en`. El servidor exige un motivo de 3 a 1000 caracteres. No existe una columna física `motivo_cierre` en alertas y no se requiere inventarla para documentar la implementación.

Ampliar las secciones de alertas y auditoría del diccionario y la explicación de permisos. Administrador y Supervisor pueden registrar No procede dentro de su local; el Reponedor está limitado a alertas sin asignar o asignadas a sí mismo. Tomar y cerrar una atención normal corresponde al Reponedor.

### 5 Instrucciones y rutas heredadas

`LEEME.md` y `API_REGOVA.md` conservan afirmaciones de que la actualización o activación sobre la base del usuario aún estaba pendiente. Son afirmaciones históricas y no prueban el estado actual de la instalación. Deben fecharse como antecedentes o sustituirse por instrucciones condicionales para cada instalación.

`API_REGOVA.md` remite a `docs/CONSTRUCCION_API_Y_BD.md`, mientras que la copia revisada se encuentra en `docs/modelado/03_Documentacion/CONSTRUCCION_API_Y_BD.md`. Revisar el enlace según la ubicación de entrega.

### 6 Ensayo de restauración ya documentado

`CONSTRUCCION_API_Y_BD.md`, sección 10, describe la restauración de un respaldo en una instancia separada y la recuperación de cinco análisis, cinco resultados y cuatro usuarios de esa copia. Por tanto, no corresponde afirmar que nunca se realizó una prueba de restauración.

Esta revisión encontró la descripción documental; no repitió la restauración ni verificó nuevamente sus registros de ejecución. Conservar el resultado con su alcance y enlazar la evidencia del ensayo. La comprobación de respaldos futuros sigue siendo una actividad recurrente.

## Elementos que ya están alineados

- FastAPI y PostgreSQL, con acceso mediante psycopg y permisos en servidor.
- Pasillo y referencia asociados a cada captura; no se exige un catálogo de góndolas.
- Tabla gondolas conservada como compatibilidad, con referencias opcionales.
- Versiones de modelo y configuración ligadas a cada análisis.
- Revisiones humanas separadas de la predicción original.
- Clases aceptable, baja, crítica y no evaluable, con umbrales separados del detector.
- Imágenes en archivos y metadatos/referencias en PostgreSQL; PDF generado a demanda.
- Distinción entre las entidades de negocio del MER y las tablas auxiliares del ML.

## Alcance de la comprobación

Se leyeron los Markdown, el diccionario, el SQL de referencia, las migraciones 000–003, el JSON histórico y la estructura XML de los diagramas editables completos. El ML completo contiene 14 nodos y 22 relaciones; el MER completo contiene 11 entidades y 18 relaciones. No se hizo una nueva revisión visual de los PNG ni una validación de toda la integridad con PostgreSQL en ejecución.

La revisión identifica actualizaciones necesarias; no certifica todavía el paquete completo como actualizado ni como aceptado académicamente.
